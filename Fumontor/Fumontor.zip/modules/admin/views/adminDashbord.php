<div class="content-wrapper">
            <h1 class="form-heading cool-border text-theme">Welcome to Fumontor</h1>
        </div> <!-- .content-wrapper -->
    </main> <!-- .cd-main-content -->