<div class="page-content-wrapper">
    <div class="page-content">
        <!-- BEGIN PAGE HEADER-->
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-success">
                    <h1>
                        <?php echo $message; ?>
                    </h1>
                </div>
            </div>
        </div>
    </div>
</div>