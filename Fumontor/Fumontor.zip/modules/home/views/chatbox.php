<div class="chat-box">
    <div class="chatbox-head">
        my--head
    </div>
    <div class="chatbox-body">
        my-bodyu
    </div>
    <div class="chatbox-foot">
        my foot
    </div>
</div>