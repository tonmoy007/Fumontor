<div id="cd-shadow-layer"></div>

<div id="cd-cart">
<h1 class="cart-logo">Cart  &nbsp;&nbsp;&nbsp;<i class="fa fa-shopping-cart"></i></h1>
  <a id="dismiss-cart"  class="pull-right"></a>
  <div id="cart-form">
      

    <ul class="cd-cart-items">
    <div class=" cart-empty alert alert-info "> No items in the cart </div>
          <li>
          <div>
            <span class="cd-qty">quantity x</span> 
            'title'
          </div>
          <div class="cd-price">৳ 'price',?></div>
          <a href="javascript::void(0)" class="cd-item-remove cd-img-replace"  >Remove</a>
          </li>

       
           </ul> <!-- cd-cart-items -->

    <div class="cd-cart-total">
      <p>Subtotal <span>৳ <label class="total"> $total</label></span></p>

    </div> <!-- cd-cart-total -->

    <a href="#0" class=" checkout btn btn-danger btn-wide">Proceed to Checkout</a>
    
    <p class="cd-go-to-cart"><a href="#0">Go to cart page</a></p>
  </div>
  </div> <!-- cd-cart -->
       
  

     


