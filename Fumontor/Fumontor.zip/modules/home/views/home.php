


    
    

    
    
    
    <div class="main-div" >
    <product-loading></product-loading>
        <div ng-view >
        
        </div>
        <noscript>
            <div class="container space">
                <div class="alert bg-white text-theme cool-shadow">
                    <strong>It seems like this browser does not support javascript </strong>
                    we need javascript support to run this application please update your browser or check if the javascript is disabled or not
                </div>
            </div>
        </noscript>
        
    </div>
    
   



