<a>
  <i class="fa fa-location-arrow"></i>&nbsp;&nbsp;<span  ng-bind-html="match.label | uibTypeaheadHighlight:query" ></span>
</a>