

<div class="col-sm-2 grid fadeIn animated">
    <div class="grid-lg">
        <div class="additem-block">
            <a href="" title="add new item" ng-click="singleItemDisplay(type)" class="fu-modal-trigger" modal-id="#addNewItem">
            <i class="fa fa-plus"></i>
            <strong>add new item</strong>
            </a>            
        </div>
    </div>
</div>



