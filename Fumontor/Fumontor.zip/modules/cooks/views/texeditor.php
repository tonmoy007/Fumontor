<link rel="stylesheet" type="text/css" href="assets/css/widgEditor.css">
<script type="text/javascript" src="assets/js/widgEditor.js"></script>

<div class="form-group">
  <textarea id="description" name="description" class="widgEditor nothing">Description</textarea>
  <div class="help-text">Enter a short description of your recipie </div>
</div>