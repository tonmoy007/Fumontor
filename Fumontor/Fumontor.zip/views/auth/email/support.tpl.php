<html>
<body>
<style type="text/css" media="screen">
    strong{
        font-weight: bold;
    }
    .heading{
        text-align: center;
        width: 100%;
    }
    small{
        font-style: .7em;
    }
</style>
	<div style="background:#209aac;color:#fff;padding: 20px;">
        <h1 class="heading">Fumontor Support </h1>
        <h2><small>From:</small>&nbsp;<?php echo $name;?></h2>
        <p><strong>Email:</strong>&nbsp;<?php echo $email;?></p>
        <p><strong>Message:</strong>&nbsp;<?php echo $message;?></p>
    </div>
</body>
</html>