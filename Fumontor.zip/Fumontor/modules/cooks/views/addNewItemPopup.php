<div id="addNewItem" class="fu-modal">
    <div class="overlay"></div>
    <div id="fu-loader"><i class="fa fa-spinner fa-pulse"></i></div>
    <div class="fu-modal-container">
        <a href="" title="" ng-click="closeModel('addNewItem')" class="fu-modal-close">Close</a>
        <div class="fu-modal-header">
            <h2 class="modal-header">Add New Menu Item</h2>
        </div>
        <div class="fu-modal-body">
        <add-new-item-form></add-new-item-form>
        </div>
    </div>
    <div class="home-signup-modal-footer"></div>
</div>
