            <div class="slider bg-white cool-border " ng-show="found"  >
                <ul id="lightSlider" class="view__slider">
                    <li><a href="javascript:void(0)" title=""><img src="assets/img/f6.jpg" alt=""></a></li>
                    <li><a href="javascript:void(0)" title=""><img src="assets/img/f6.jpg" alt=""></a></li>
                    <li><a href="javascript:void(0)" title=""><img src="assets/img/f6.jpg" alt=""></a></li>
                    <li><a href="javascript:void(0)" title=""><img src="assets/img/f6.jpg" alt=""></a></li>
                    <li><a href="javascript:void(0)" title=""><img src="assets/img/f6.jpg" alt=""></a></li>
                    <li><a href="javascript:void(0)" title=""><img src="assets/img/f6.jpg" alt=""></a></li>
                    <li><a href="javascript:void(0)" title=""><img src="assets/img/f6.jpg" alt=""></a></li>
                    <li><a href="javascript:void(0)" title=""><img src="assets/img/f6.jpg" alt=""></a></li>
                </ul>
            </div>
