
<div class="kitchen-filter bg-white cool-shadow">
   <div class="kitchen-filter-container">
       <div class="filter-search"><input type="search" name="" ng-model="search" value="" placeholder="Search Kitchen"></div>
       <div class="filter-logo logo ">Filter Your Kithcen</div>
   </div>

       
</div>