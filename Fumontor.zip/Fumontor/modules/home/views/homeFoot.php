

<!-- Start FOOTER -->
<div class="page-footer">
    <div class="page-footer-inner footerInLineCss">
        2016 &copy; <a href="http://binarycraft.org"><strong>Binary Craft</strong></a>&nbsp; . All Rights Reserved.
    </div>
    
        <span class="cd-top">
        </span>
 

<!-- End FOOTER -->
<!-- Start Javasceipt -->
<!-- Start Common Script For All System -->
</div>

</body>
</html>