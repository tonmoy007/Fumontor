<a>
  <i class="fa fa-location-arrow"></i>&nbsp;&nbsp;<span bind-html-unsafe="match.label | typeaheadHighlight:query"></span>
</a>