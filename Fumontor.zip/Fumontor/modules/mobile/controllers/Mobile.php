<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Mobile extends MX_Controller
    {

    /**
     * This controller is using for configur this system
     *
     * Maps to the following URL
     * 		http://example.com/index.php/users
     * 	- or -  
     * 		http://example.com/index.php/users/<method_name>
     */
    function __construct()
        {
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('ion_auth_model');
        $this->load->model('common');
        $this->load->library('ion_auth');
        }

    //This function is useing for control the weekly holyday.
    function index(){
        
        $this->load->view('search-google');
    }
    function login(){
        $request=$this->input->post();
        $response=array();
        // echo json_encode($request);
        $email=$request['email'];
        $success=false;
        $user_state='';
        $id=null;
        $token=null;
        $message='';

        if(!empty($email)){
            if(!$this->ion_auth->identity_check($email)){
                $register = $this->ion_auth->register($request['first_name'], $email, $email, array('first_name' => $request['first_name'], 'last_name' => $request['last_name'],'name'=>$request['first_name'].' '.$request['last_name'],'phone'=>$request['phone']));
                    // $id=$this->db->insert_id();   
                if($this->ion_auth->login($email, $email, 1)){
                            $success=true;
                        }
                $user_state='new';                    
                if(isset($request['image'])){
                    $this->common->updateUserImage($email,$request['image']);
                }else{
                    $this->common->updateUserImage($email,'');
                }



            }else{
                if($this->ion_auth->login($email, $email, 1)){
                    $success=true;
                }
                if(isset($request['image'])){
                    $this->common->updateUserImage($email,$request['image']);
                }else{
                    $this->common->updateUserImage($email,'');
                }
                    $user_state='old';
            }


            $token=sha1(uniqid($email,true));
            $this->db->where('email',$email);       
            $this->db->update('users',array('access_token'=>$token));
            $this->db->select('id');
            $this->db->where('email',$email);
            $this->db->from('users');
            $qId=$this->db->get();

            foreach($qId->result_array() as $row){
                $id=$row['id'];
            }

            $response=[
            'success'=>$success,
            'user_state'=>$user_state,
            'user_id'=>$id,
            'access_token'=>$token,
            'message'=>$success?'Successfully logged in':'Login failed',
            ];

            echo json_encode($response);

        }else{
            $response=[
            'success'=>false,
            'user_state'=>$user_state,
            'user_id'=>$id,
            'access_token'=>$token,
            'message'=>'No email provided',
            ];
            echo json_encode($response);
        }
    }
   

function googleSearch($path,$encode=''){



//     # Use the Curl extension to query Google and get back a page of results
//     $url = 'https://google.com/search?q='.$path;
//     $ch = curl_init();
//     $timeout = 5;
//     curl_setopt($ch, CURLOPT_URL, $url);
//     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//     curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
//     $html = curl_exec($ch);
//     curl_close($ch);
// echo json_encode($html);
//     # Create a DOM parser object
//     $dom = new DOMDocument();

//     # Parse the HTML from Google.
//     # The @ before the method call suppresses any warnings that
//     # loadHTML might throw because of invalid HTML in the page.
    
//     $dom->loadHTML($html);

//     # Iterate over all the <a> tags
//     $response=array();
//     $i=0;
//     foreach($dom->getElementsByTagName('a') as $link) {
//             # Show the <a href>
//             $response[$i]['link']='https://google.com/'.$link->getAttribute('href');
//             $i++;
//     }
//     echo json_encode($response);

//         return;
//     $content=file_get_contents('https://google.com/search?q='.$path);
//     $file = fopen ('https://google.com/search?q='.$path, "r");
//     if (!$file) {
//         echo "<p>Unable to open remote file.\n";
//         exit;
//     }
// $html='';
    
//     while (!feof ($file)) {
//         $line = fgets ($file, 2048);
//         $html.=$line;
//          This only works if the title and its tags are on one line 
//         // if (preg_match ("@\<h3 class=\"r\"\>(.*)\</h3\>@i", $line, $out)) {
//         //     $title = $out[1];
//         //     $link='';
//         //     if(preg_match ('#http://#', $out[1],$url)){
//         //         $link=$url[1];
//         //     }
//         //     $response[]=array('link'=>$title,'url'=>$link);

//         //     // break;
//         // }
        
//     }
    // $html=fgetc($file);
// echo $html;
    $dom = new DOMDocument();

    $dom->preserveWhiteSpace = FALSE;
    // @$doc->loadHTMLFile($url);
    # Parse the HTML from Google.
    # The @ before the method call suppresses any warnings that
    # loadHTML might throw because of invalid HTML in the page.
    
    @$dom->loadHTMLFile('https://google.com/search?q='.$path.'&tbm=vid');

    # Iterate over all the <a> tags
    $response=array();
    $i=0;
    foreach($dom->getElementsByTagName('a') as $link) {
            # Show the <a href>
            
            $links=$link->getAttribute('href');
            $response[$i]['text']=$link->nodeValue;

            $response[$i]['link']=preg_replace("[^/url?q=]",'', $links);
            if(strcmp($link->nodeValue,'youtube.com')==0){
                $response[$i]['link']='http://youtube.com'.$response[$i]['link'];
            }
            $i++;
    }
    $i=0;

    echo json_encode($response);
    // echo json_encode($response);
    // fclose($file);
    // $send['data']=$content;
    // echo json_encode($send);
    // echo json_encode($this->output->set_output($send)) ;
    
}

function config(){
    echo json_encode($this->config->item('facebook')['app_id']);
}




























    }
