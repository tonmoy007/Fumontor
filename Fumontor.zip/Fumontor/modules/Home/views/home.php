<link rel="stylesheet" href="assets/css/admin/gridProducts.css">
<link rel="stylesheet" href="assets/css/animate.css">
<link rel="stylesheet" href="assets/css/fu-modal.css">
<link rel="stylesheet" href="assets/css/home/rzslider.min.css">


    
    

    
    
    
    <div class="main-div" >
    <product-loading></product-loading>
        <div ng-view>
        
        </div>
    </div>
    
   



