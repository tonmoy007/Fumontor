</div>

<!-- Start FOOTER -->
<div class="page-footer">
    <div class="page-footer-inner footerInLineCss">
        2015 &copy; <a href="http://binarycraft.org"><strong>Binary Craft</strong></a>&nbsp; . All Rights Reserved.
    </div>
    
        <span class="cd-top">
        </span>
 

<!-- End FOOTER -->
<!-- Start Javasceipt -->
<!-- Start Common Script For All System -->
</div>
<script src="assets/js/home/classie.js"></script>
<script src="assets/js/home/clipboard.min.js"></script>


<script src="assets/js/home/jquery.placeholder.js"></script>
<script src="assets/bootstrap/js/google-code-prettify/prettify.js"></script>
<script src="assets/js/home/application.js"></script>
<script src="assets/js/admin/jquery.menu-aim.js"></script>
<script src="assets/js/admin/main.js"></script> <!-- Resource jQuery -->

</body>
</html>