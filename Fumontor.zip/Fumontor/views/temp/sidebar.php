
<link rel="stylesheet" type="text/css" href="assets/css/sidebar.css">

<div class="component-container col-xs-12 col-sm-12 col-md-3 col-lg-4">
    <div class="sidebar-content">
        <a href="" class="btn btn-info tiny pull-right see-more">see more</a>
        <div class="content-header">
            <h2 class="content-heading">Similer</h2>
        </div>
        <div class="content-body">
            <?php for ($i=0; $i <4 ; $i++) {?>
        <div class="content-container center">
            <div class="content-block portrate">

            <div class="featured-img">
            <a href="" class="img-overlay block-link"><i class="mdi-action-search"></i></a>
            <img src="assets/img/food1.jpg">

            </div>
            <div class="content-info">
                <div class="info-overlay"></div>
                <h2 class="product-title"><a href="">Khichuri Musallam</a></h2>
                <span class="product-subtitle"><a href="">Mr. Kamal Khan</a></span>
                <a href="" class="block-link">
                    <div class="product-description">
                    Ut leo. Etiam feugiat lorem non metus. Aenean posuere, 
                    tortor sed cursus feugiat, nunc augue blandit nunc, eu 
                    sollicitudin urna dolor sagittis lacus.

                    Phasellus volutpat, metus eget egestas mollis, 
                    lacus lacus blandit dui, id egestas quam mauris ut lacus. 
                    Fusce vel dui. Morbi nec metus.

                    Quisque malesuada placerat nisl. Cras id dui. Vestibulum 
                    suscipit nulla quis orci.

                </div> 
                </a>

                <div class="content-footer">
                    <span class="rating-stars tiny-star" href="javascript:void(0)">
                    <div class="current-rating" style="width:75%"></div>
                </span>
                <a href="" class="feature-link">Link</a>
                </div>

                </div>
            </div>
           </div>
        <?php }?>
        
<?php for ($i=0; $i <4 ; $i++) { ?>
   

        <div class="content-container center">
            <div class="content-block landscape">

            <div class="featured-img">
            <a href="" class="img-overlay block-link"><i class="mdi-action-search"></i></a>
            <img src="assets/img/food1.jpg">

            </div>
            <div class="content-info">
                <div class="info-overlay"></div>
                <h2 class="product-title"><a href="">Khichuri Musallam</a></h2>
                <span class="product-subtitle"><a href="">Mr. Kamal Khan</a></span>
                <a href="" class="block-link">
                    <div class="product-description">
                    Ut leo. Etiam feugiat lorem non metus. Aenean posuere, 
                    tortor sed cursus feugiat, nunc augue blandit nunc, eu 
                    sollicitudin urna dolor sagittis lacus.

                    Phasellus volutpat, metus eget egestas mollis, 
                    lacus lacus blandit dui, id egestas quam mauris ut lacus. 
                    Fusce vel dui. Morbi nec metus.

                    Quisque malesuada placerat nisl. Cras id dui. Vestibulum 
                    suscipit nulla quis orci.

                </div> 
                </a>

                
                <div class="content-footer">
                    <span class="rating-stars tiny-star" href="javascript:void(0)">
                    <div class="current-rating" style="width:75%"></div>
                </span>
                <a href="" class="feature-link">Link</a>
                </div>

                </div>
                
            </div>
           </div>
           <?php }?>



        </div>
        
       
    </div>
</div>