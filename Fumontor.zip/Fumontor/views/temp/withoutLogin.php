 <li class="dropdown">
    <a href="#" data-target="#" class="dropdown-toggle" data-toggle="dropdown"><span>Menu </span>&nbsp;<i class="mdi-navigation-apps"></i> </a>
    <ul class="dropdown-menu">
        <li><a href="javascript:void(0)">Action</a></li>
        <li><a href="javascript:void(0)">Another action</a></li>
        <li><a href="javascript:void(0)">Something else here</a></li>
        <li class="divider"></li>
        <li><a href="javascript:void(0)">Separated link</a></li>
    </ul>
</li>

<li class="register-btn">
    <a href="index.php/auth/login" class="btn btn-login mid-btn"  >
    <i class="fa fa-sign-in"></i> &nbsp; login
    </a>
</li>

