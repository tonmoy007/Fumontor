</div>

<!-- Start FOOTER -->
<div class="page-footer">
    <div class="page-footer-inner footerInLineCss">
        2015 &copy; <a href="http://binarycraft.org"><strong>Binary Craft</strong></a>&nbsp; . All Rights Reserved.
    </div>
    
        <span class="cd-top">
        </span>
 

<!-- End FOOTER -->
<!-- Start Javasceipt -->
<!-- Start Common Script For All System -->
</div>
<script src="assets/js/home/classie.js"></script>
<script src="assets/js/home/clipboard.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/home/main.js"></script>
<script src="assets/js/home/scrollspy.js"></script>
<script src="assets/js/home/flatui-checkbox.js"></script>

</body>
</html>