<div id="cd-shadow-layer"></div>

<div id="cd-cart" ng-class="{'speed-in':showCart}">
<h1 class="cart-logo">Cart  &nbsp;&nbsp;&nbsp;<i class="fa fa-shopping-cart"></i></h1>
  <a id="dismiss-cart"  class="pull-right right-arrow" ng-click="showCart=!showCart"> &#8680;</a>
  <cart-form></cart-form>
  </div> <!-- cd-cart -->
       
  

     


