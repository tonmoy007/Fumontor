<div id="cd-shadow-layer"></div>

<div id="cd-cart" ng-class="{'speed-in':showCart}">
<h1 class="cart-logo">Cart  &nbsp;&nbsp;&nbsp;<i class="fa fa-shopping-cart"></i></h1>
  <a id="dismiss-cart"  class="pull-right" ng-click="showCart=!showCart"></a>
  <cart-form></cart-form>
  </div> <!-- cd-cart -->
       
  

     


