/* Custom filtering function which will search data in column four between two values */
$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = parseInt( $('#min').val(), 10 );
        var max = parseInt( $('#max').val(), 10 );
        var age = parseFloat( data[5] ) || 0; // use data for the age column

        if ( ( isNaN( min ) && isNaN( max ) ) ||
             ( isNaN( min ) && age <= max ) ||
             ( min <= age   && isNaN( max ) ) ||
             ( min <= age   && age <= max ) )
        {
            return true;
        }
        return false;
    }
);

$(document).ready(function() {
    var table = $('#cooks-table').DataTable(
        {
        "dom" : 'CT<"clear">lfrtip',
            "oTableTools" : {
                "sSwfPath" : "assets/swf/copy_csv_xls_pdf.swf",
                "aButtons" : [ "copy", "print", {
                    "sExtends" : "collection",
                    "sButtonText" : "Save",
                    "aButtons" : [ "csv", "xls", 
                    {
                        "sExtends":"pdf",
                        "oSelectorOpts": { filter: 'applied', order: 'current' },
                    } ],

                } ]
            }

        });
    
    // Event listener to the two range filtering inputs to redraw on input
    $('#min, #max').keyup( function() {
        table.draw();
    } );


} );